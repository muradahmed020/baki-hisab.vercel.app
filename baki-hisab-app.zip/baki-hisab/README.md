# 📒 বাকি হিসাব খাতা — ডিপ্লয় গাইড

## ধাপ ১: GitHub অ্যাকাউন্ট খুলুন (ফ্রি)
1. https://github.com যান
2. "Sign Up" করুন (ইমেইল দিয়ে)

## ধাপ ২: নতুন Repository তৈরি করুন
1. GitHub-এ লগইন করুন
2. উপরে ডানে "+" বাটন → "New repository"
3. নাম দিন: `baki-hisab`
4. "Create repository" চাপুন

## ধাপ ৩: ফাইল আপলোড করুন
1. "uploading an existing file" লিংকে ক্লিক করুন
2. এই ZIP-এর সব ফাইল ড্র্যাগ করুন
3. "Commit changes" চাপুন

## ধাপ ৪: Vercel-এ ডিপ্লয় করুন (ফ্রি)
1. https://vercel.com যান
2. "Sign Up with GitHub" করুন
3. "New Project" → আপনার `baki-hisab` সিলেক্ট করুন
4. "Deploy" চাপুন
5. ✅ কয়েক মিনিটে আপনার লিংক পাবেন: `baki-hisab.vercel.app`

## ধাপ ৫: আইফোনে ইন্সটল করুন
1. iPhone-এ **Safari** খুলুন (Chrome কাজ করবে না)
2. আপনার Vercel লিংক খুলুন
3. নিচে **Share বাটন** (□↑) চাপুন
4. **"Add to Home Screen"** চাপুন
5. নাম দিন → **"Add"** চাপুন
6. ✅ হোম স্ক্রিনে অ্যাপ আইকন দেখা যাবে!

## ধাপ ৬: Android-এ ইন্সটল করুন
1. Chrome-এ লিংক খুলুন
2. তিনটি ডট মেনু → "Add to Home Screen"
3. ✅ হয়ে গেল!

## ডেটা সম্পর্কে
- ডেটা ফোনের **localStorage**-এ থাকে (ফ্রি, ইনফিনিটি)
- নিয়মিত **💾 ব্যাকআপ** নিন → Google Drive-এ রাখুন
- নতুন ফোনে গেলে **📂 রিস্টোর** করুন

---
**সাপোর্ট লাগলে Claude-কে জিজ্ঞেস করুন!**
