import { useState, useEffect, useRef } from "react";

const formatDate = (dateStr) => {
  const d = new Date(dateStr);
  return d.toLocaleDateString("bn-BD", { day: "numeric", month: "long", year: "numeric" });
};

const todayStr = () => new Date().toISOString().split("T")[0];
const generateId = () => Math.random().toString(36).substr(2, 9);
const STORAGE_KEY = "baki-hisab-data";

export default function BakiHisab() {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState("dashboard");
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [showAddTx, setShowAddTx] = useState(null);
  const [search, setSearch] = useState("");
  const [newCustomer, setNewCustomer] = useState({ name: "", phone: "" });
  const [newTx, setNewTx] = useState({ amount: "", note: "", date: todayStr() });
  const [toast, setToast] = useState(null);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      setCustomers(stored ? JSON.parse(stored) : []);
    } catch {
      setCustomers([]);
    }
    setLoading(false);
  }, []);

  const save = (data) => {
    setCustomers(data);
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }
    catch { showToast("সেভ করতে সমস্যা হয়েছে", "error"); }
  };

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const getBalance = (c) =>
    c.transactions.reduce((sum, t) => t.type === "baki" ? sum + t.amount : sum - t.amount, 0);

  const totalBaki = customers.reduce((sum, c) => sum + Math.max(0, getBalance(c)), 0);
  const activeCustomers = customers.filter(c => getBalance(c) > 0).length;

  const filtered = customers.filter(c =>
    c.name.includes(search) || c.phone.includes(search)
  );

  const addCustomer = () => {
    if (!newCustomer.name.trim()) return showToast("নাম দিন", "error");
    const c = { id: generateId(), ...newCustomer, createdAt: todayStr(), transactions: [] };
    save([...customers, c]);
    setNewCustomer({ name: "", phone: "" });
    setShowAddCustomer(false);
    showToast("কাস্টমার যোগ হয়েছে ✓");
  };

  const addTransaction = () => {
    if (!newTx.amount || isNaN(newTx.amount)) return showToast("পরিমাণ দিন", "error");
    const tx = { id: generateId(), type: showAddTx, amount: parseFloat(newTx.amount), note: newTx.note, date: newTx.date };
    const updated = customers.map(c =>
      c.id === selectedCustomer.id ? { ...c, transactions: [...c.transactions, tx] } : c
    );
    save(updated);
    setSelectedCustomer(updated.find(c => c.id === selectedCustomer.id));
    setNewTx({ amount: "", note: "", date: todayStr() });
    setShowAddTx(null);
    showToast(showAddTx === "baki" ? "বাকি যোগ হয়েছে ✓" : "পরিশোধ যোগ হয়েছে ✓");
  };

  const exportData = () => {
    const blob = new Blob([JSON.stringify(customers, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `baki-hisab-backup-${todayStr()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast("✅ ব্যাকআপ ডাউনলোড হয়েছে!");
  };

  const importData = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target.result);
        if (!Array.isArray(parsed)) throw new Error();
        if (!confirm(`${parsed.length} জন কাস্টমারের ডেটা লোড করবেন?`)) return;
        save(parsed);
        showToast(`✅ ${parsed.length} জন কাস্টমার লোড হয়েছে!`);
      } catch { showToast("ফাইলটি সঠিক নয়", "error"); }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  const deleteCustomer = (id) => {
    if (!confirm("এই কাস্টমার মুছে ফেলবেন?")) return;
    save(customers.filter(c => c.id !== id));
    setView("dashboard");
    showToast("কাস্টমার মুছে ফেলা হয়েছে");
  };

  const deleteTx = (txId) => {
    const updated = customers.map(c =>
      c.id === selectedCustomer.id
        ? { ...c, transactions: c.transactions.filter(t => t.id !== txId) }
        : c
    );
    save(updated);
    setSelectedCustomer(updated.find(c => c.id === selectedCustomer.id));
    showToast("এন্ট্রি মুছে ফেলা হয়েছে");
  };

  const printReport = () => {
    const c = selectedCustomer;
    const balance = getBalance(c);
    const win = window.open("", "_blank");
    win.document.write(`
      <html><head><title>বাকি হিসাব - ${c.name}</title>
      <style>
        body{font-family:serif;padding:30px;color:#1a1a1a}
        h1{font-size:24px;border-bottom:2px solid #333;padding-bottom:10px}
        table{width:100%;border-collapse:collapse;margin-top:20px}
        th{background:#2d6a4f;color:white;padding:10px;text-align:left}
        td{padding:8px 10px;border-bottom:1px solid #ddd}
        .baki{color:#c0392b;font-weight:bold}
        .pay{color:#27ae60;font-weight:bold}
        .total{margin-top:20px;font-size:20px;font-weight:bold;text-align:right}
      </style></head><body>
      <h1>🛒 বাকি হিসাব</h1>
      <p><b>নাম:</b> ${c.name} &nbsp;&nbsp; <b>ফোন:</b> ${c.phone||"—"}</p>
      <p><b>তারিখ:</b> ${new Date().toLocaleDateString("bn-BD")}</p>
      <table>
        <tr><th>তারিখ</th><th>বিবরণ</th><th>বাকি</th><th>পরিশোধ</th></tr>
        ${c.transactions.map(t=>`<tr>
          <td>${formatDate(t.date)}</td><td>${t.note||"—"}</td>
          <td class="baki">${t.type==="baki"?"৳"+t.amount:""}</td>
          <td class="pay">${t.type==="payment"?"৳"+t.amount:""}</td>
        </tr>`).join("")}
      </table>
      <div class="total" style="color:${balance>0?"#c0392b":"#27ae60"}">
        মোট বাকি: ৳${Math.abs(balance).toLocaleString("bn-BD")}
      </div>
      <script>window.onload=()=>window.print();</script>
      </body></html>`);
    win.document.close();
  };

  const printAll = () => {
    const win = window.open("", "_blank");
    win.document.write(`
      <html><head><title>সকল বাকির তালিকা</title>
      <style>
        body{font-family:serif;padding:30px}
        table{width:100%;border-collapse:collapse;margin-top:20px}
        th{background:#2d6a4f;color:white;padding:10px;text-align:left}
        td{padding:8px 10px;border-bottom:1px solid #ddd}
        .amt{font-weight:bold;color:#c0392b}
        tfoot td{background:#f5f5f5;font-weight:bold}
      </style></head><body>
      <h1>🛒 সকল বাকির তালিকা</h1>
      <p>তারিখ: ${new Date().toLocaleDateString("bn-BD")}</p>
      <table>
        <tr><th>#</th><th>নাম</th><th>ফোন</th><th>বাকি</th></tr>
        ${customers.filter(c=>getBalance(c)>0).map((c,i)=>`<tr>
          <td>${i+1}</td><td>${c.name}</td><td>${c.phone||"—"}</td>
          <td class="amt">৳${getBalance(c).toLocaleString("bn-BD")}</td>
        </tr>`).join("")}
        <tfoot><tr><td colspan="3" style="text-align:right">মোট:</td>
          <td class="amt">৳${totalBaki.toLocaleString("bn-BD")}</td></tr></tfoot>
      </table>
      <script>window.onload=()=>window.print();</script>
      </body></html>`);
    win.document.close();
  };

  const Modal = ({ title, onClose, children }) => (
    <div style={{ position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",zIndex:1000,display:"flex",alignItems:"center",justifyContent:"center",padding:"20px" }}>
      <div style={{ background:"white",borderRadius:"16px",padding:"28px",width:"100%",maxWidth:"420px",boxShadow:"0 20px 60px rgba(0,0,0,0.3)" }}>
        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"20px" }}>
          <h3 style={{ margin:0,fontSize:"18px",color:"#1a3a2a" }}>{title}</h3>
          <button onClick={onClose} style={{ border:"none",background:"none",fontSize:"22px",cursor:"pointer" }}>×</button>
        </div>
        {children}
      </div>
    </div>
  );

  const inp = { width:"100%",padding:"12px 14px",borderRadius:"10px",border:"1.5px solid #d0e8d8",fontSize:"15px",fontFamily:"inherit",boxSizing:"border-box",marginBottom:"12px",outline:"none" };
  const btn = (bg, color="white") => ({ padding:"12px 18px",background:bg,color,border:"none",borderRadius:"10px",fontSize:"14px",cursor:"pointer",fontFamily:"inherit",fontWeight:"600",display:"flex",alignItems:"center",gap:"6px",whiteSpace:"nowrap" });

  if (loading) return (
    <div style={{ minHeight:"100vh",background:"#f0f7f3",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"sans-serif" }}>
      <div style={{ textAlign:"center",color:"#1b5e3b" }}>
        <div style={{ fontSize:"40px",marginBottom:"12px" }}>📒</div>
        <div style={{ fontSize:"16px",fontWeight:600 }}>লোড হচ্ছে...</div>
      </div>
    </div>
  );

  // ── DASHBOARD ──
  if (view === "dashboard") return (
    <div style={{ minHeight:"100vh",background:"#f0f7f3",fontFamily:"'Hind Siliguri','Noto Sans Bengali',sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet" />

      <div style={{ background:"linear-gradient(135deg,#1b5e3b 0%,#2d8a5e 100%)",padding:"24px 20px 80px",color:"white" }}>
        <div style={{ maxWidth:"700px",margin:"0 auto" }}>
          <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"12px" }}>
            <div>
              <div style={{ fontSize:"12px",opacity:0.75,letterSpacing:"1px" }}>আপনার দোকান</div>
              <h1 style={{ margin:"4px 0 0",fontSize:"24px",fontWeight:700 }}>বাকি হিসাব খাতা</h1>
            </div>
            <div style={{ display:"flex",gap:"8px",flexWrap:"wrap" }}>
              <button onClick={exportData} style={{ ...btn("rgba(255,255,255,0.2)","white"),border:"1.5px solid rgba(255,255,255,0.4)" }}>💾 ব্যাকআপ</button>
              <label style={{ ...btn("rgba(255,255,255,0.2)","white"),border:"1.5px solid rgba(255,255,255,0.4)",cursor:"pointer" }}>
                📂 রিস্টোর<input type="file" accept=".json" onChange={importData} style={{ display:"none" }} />
              </label>
              <button onClick={printAll} style={{ ...btn("rgba(255,255,255,0.2)","white"),border:"1.5px solid rgba(255,255,255,0.4)" }}>🖨️</button>
              <button onClick={() => setShowAddCustomer(true)} style={btn("white","#1b5e3b")}>+ নতুন</button>
            </div>
          </div>

          <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:"12px",marginTop:"24px" }}>
            {[
              { label:"মোট বাকি", value:`৳${totalBaki.toLocaleString("bn-BD")}`, icon:"💰" },
              { label:"বাকিদার", value:`${activeCustomers} জন`, icon:"⚠️" },
              { label:"কাস্টমার", value:`${customers.length} জন`, icon:"👥" },
            ].map((s,i) => (
              <div key={i} style={{ background:"rgba(255,255,255,0.15)",borderRadius:"12px",padding:"14px",backdropFilter:"blur(10px)" }}>
                <div style={{ fontSize:"20px" }}>{s.icon}</div>
                <div style={{ fontSize:"18px",fontWeight:700,margin:"4px 0 2px" }}>{s.value}</div>
                <div style={{ fontSize:"11px",opacity:0.8 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth:"700px",margin:"-48px auto 0",padding:"0 16px 40px" }}>
        <div style={{ background:"white",borderRadius:"14px",padding:"14px",boxShadow:"0 4px 20px rgba(0,0,0,0.08)",marginBottom:"14px" }}>
          <input placeholder="🔍 নাম বা ফোন নম্বর দিয়ে খুঁজুন..." value={search}
            onChange={e => setSearch(e.target.value)} style={{ ...inp,marginBottom:0 }} />
        </div>

        {filtered.length === 0 && (
          <div style={{ textAlign:"center",padding:"40px",color:"#999",background:"white",borderRadius:"14px" }}>
            {customers.length === 0 ? "এখনো কোনো কাস্টমার নেই। + নতুন বাটন চাপুন।" : "কোনো কাস্টমার পাওয়া যায়নি"}
          </div>
        )}

        <div style={{ display:"flex",flexDirection:"column",gap:"10px" }}>
          {filtered.sort((a,b) => getBalance(b)-getBalance(a)).map(c => {
            const bal = getBalance(c);
            return (
              <div key={c.id} onClick={() => { setSelectedCustomer(c); setView("customer"); }}
                style={{ background:"white",borderRadius:"14px",padding:"16px 18px",boxShadow:"0 2px 12px rgba(0,0,0,0.06)",cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center",border:bal>0?"1.5px solid #ffe0e0":"1.5px solid #e0f4e8" }}>
                <div style={{ display:"flex",alignItems:"center",gap:"12px" }}>
                  <div style={{ width:"44px",height:"44px",borderRadius:"50%",background:bal>0?"#fff0f0":"#f0fff4",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"18px",border:`2px solid ${bal>0?"#ffc9c9":"#a7f3c9"}`,fontWeight:700,color:bal>0?"#c0392b":"#27ae60" }}>
                    {c.name[0]}
                  </div>
                  <div>
                    <div style={{ fontWeight:700,fontSize:"15px",color:"#1a3a2a" }}>{c.name}</div>
                    <div style={{ fontSize:"12px",color:"#888",marginTop:"2px" }}>📞 {c.phone||"—"} · {c.transactions.length} টি</div>
                  </div>
                </div>
                <div style={{ textAlign:"right" }}>
                  <div style={{ fontWeight:700,fontSize:"17px",color:bal>0?"#c0392b":"#27ae60" }}>৳{Math.abs(bal).toLocaleString("bn-BD")}</div>
                  <div style={{ fontSize:"11px",padding:"2px 8px",borderRadius:"20px",marginTop:"4px",background:bal>0?"#fff0f0":"#f0fff4",color:bal>0?"#c0392b":"#27ae60" }}>
                    {bal>0?"বাকি আছে":bal===0?"পরিষ্কার":"অতিরিক্ত"}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {showAddCustomer && (
        <Modal title="নতুন কাস্টমার" onClose={() => setShowAddCustomer(false)}>
          <input placeholder="নাম *" value={newCustomer.name} onChange={e => setNewCustomer({...newCustomer,name:e.target.value})} style={inp} />
          <input placeholder="ফোন নম্বর" value={newCustomer.phone} onChange={e => setNewCustomer({...newCustomer,phone:e.target.value})} style={inp} />
          <button onClick={addCustomer} style={{ ...btn("#1b5e3b"),width:"100%",justifyContent:"center" }}>✓ যোগ করুন</button>
        </Modal>
      )}

      {toast && (
        <div style={{ position:"fixed",bottom:"24px",left:"50%",transform:"translateX(-50%)",background:toast.type==="error"?"#c0392b":"#1b5e3b",color:"white",padding:"12px 24px",borderRadius:"30px",boxShadow:"0 8px 24px rgba(0,0,0,0.2)",fontSize:"15px",zIndex:2000 }}>
          {toast.msg}
        </div>
      )}
    </div>
  );

  // ── CUSTOMER DETAIL ──
  const bal = selectedCustomer ? getBalance(selectedCustomer) : 0;
  const sc = customers.find(c => c.id === selectedCustomer?.id) || selectedCustomer;

  return (
    <div style={{ minHeight:"100vh",background:"#f0f7f3",fontFamily:"'Hind Siliguri','Noto Sans Bengali',sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet" />

      <div style={{ background:"linear-gradient(135deg,#1b5e3b 0%,#2d8a5e 100%)",padding:"20px 20px 70px",color:"white" }}>
        <div style={{ maxWidth:"700px",margin:"0 auto" }}>
          <button onClick={() => setView("dashboard")} style={{ ...btn("rgba(255,255,255,0.2)","white"),border:"1.5px solid rgba(255,255,255,0.3)",marginBottom:"16px",fontSize:"14px" }}>← পিছনে</button>
          <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"12px" }}>
            <div>
              <h2 style={{ margin:0,fontSize:"22px" }}>{sc.name}</h2>
              <div style={{ opacity:0.8,marginTop:"4px" }}>📞 {sc.phone||"—"}</div>
            </div>
            <div style={{ textAlign:"right" }}>
              <div style={{ fontSize:"26px",fontWeight:700 }}>৳{Math.abs(bal).toLocaleString("bn-BD")}</div>
              <div style={{ fontSize:"12px",opacity:0.8 }}>{bal>0?"মোট বাকি":bal===0?"হিসাব পরিষ্কার":"অতিরিক্ত পরিশোধ"}</div>
            </div>
          </div>
          <div style={{ display:"flex",gap:"8px",marginTop:"18px",flexWrap:"wrap" }}>
            <button onClick={() => setShowAddTx("baki")} style={btn("#c0392b")}>+ বাকি দিন</button>
            <button onClick={() => setShowAddTx("payment")} style={btn("#27ae60")}>✓ পরিশোধ নিন</button>
            <button onClick={printReport} style={{ ...btn("rgba(255,255,255,0.2)","white"),border:"1.5px solid rgba(255,255,255,0.4)" }}>🖨️ প্রিন্ট</button>
            <button onClick={() => deleteCustomer(sc.id)} style={{ ...btn("rgba(255,0,0,0.2)","rgba(255,255,255,0.8)") }}>🗑️</button>
          </div>
        </div>
      </div>

      <div style={{ maxWidth:"700px",margin:"-48px auto 0",padding:"0 16px 40px" }}>
        <div style={{ background:"white",borderRadius:"16px",boxShadow:"0 4px 20px rgba(0,0,0,0.08)",overflow:"hidden" }}>
          <div style={{ padding:"16px 20px",borderBottom:"1px solid #f0f0f0",fontWeight:700,color:"#1a3a2a" }}>লেনদেনের ইতিহাস</div>
          {sc.transactions.length === 0 && <div style={{ textAlign:"center",padding:"40px",color:"#aaa" }}>কোনো লেনদেন নেই</div>}
          {[...sc.transactions].reverse().map((t,i) => (
            <div key={t.id} style={{ padding:"14px 20px",borderBottom:"1px solid #f7f7f7",display:"flex",justifyContent:"space-between",alignItems:"center",background:i%2===0?"white":"#fafafa" }}>
              <div style={{ display:"flex",alignItems:"center",gap:"12px" }}>
                <div style={{ width:"36px",height:"36px",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"15px",background:t.type==="baki"?"#fff0f0":"#f0fff4" }}>
                  {t.type==="baki"?"📤":"📥"}
                </div>
                <div>
                  <div style={{ fontWeight:600,fontSize:"14px",color:"#1a3a2a" }}>{t.note||(t.type==="baki"?"বাকি":"পরিশোধ")}</div>
                  <div style={{ fontSize:"11px",color:"#999",marginTop:"2px" }}>{formatDate(t.date)}</div>
                </div>
              </div>
              <div style={{ display:"flex",alignItems:"center",gap:"10px" }}>
                <div style={{ textAlign:"right" }}>
                  <div style={{ fontWeight:700,fontSize:"15px",color:t.type==="baki"?"#c0392b":"#27ae60" }}>
                    {t.type==="baki"?"+":"-"}৳{t.amount.toLocaleString("bn-BD")}
                  </div>
                </div>
                <button onClick={() => deleteTx(t.id)} style={{ border:"none",background:"none",cursor:"pointer",color:"#ccc",fontSize:"18px" }}>×</button>
              </div>
            </div>
          ))}
          {sc.transactions.length > 0 && (
            <div style={{ padding:"14px 20px",background:"#f8fdf9",display:"flex",justifyContent:"space-between",borderTop:"2px solid #e0f0e8" }}>
              <span style={{ fontWeight:700,color:"#1a3a2a" }}>মোট বাকি:</span>
              <span style={{ fontWeight:700,fontSize:"17px",color:bal>0?"#c0392b":"#27ae60" }}>৳{Math.abs(bal).toLocaleString("bn-BD")}</span>
            </div>
          )}
        </div>
      </div>

      {showAddTx && (
        <Modal title={showAddTx==="baki"?"নতুন বাকি যোগ করুন":"পরিশোধ গ্রহণ করুন"} onClose={() => setShowAddTx(null)}>
          <input type="number" placeholder="পরিমাণ (টাকা) *" value={newTx.amount} onChange={e => setNewTx({...newTx,amount:e.target.value})} style={inp} />
          <input placeholder="বিবরণ (চাল, তেল...)" value={newTx.note} onChange={e => setNewTx({...newTx,note:e.target.value})} style={inp} />
          <input type="date" value={newTx.date} onChange={e => setNewTx({...newTx,date:e.target.value})} style={inp} />
          <button onClick={addTransaction} style={{ ...btn(showAddTx==="baki"?"#c0392b":"#27ae60"),width:"100%",justifyContent:"center" }}>
            ✓ {showAddTx==="baki"?"বাকি যোগ করুন":"পরিশোধ নিন"}
          </button>
        </Modal>
      )}

      {toast && (
        <div style={{ position:"fixed",bottom:"24px",left:"50%",transform:"translateX(-50%)",background:toast.type==="error"?"#c0392b":"#1b5e3b",color:"white",padding:"12px 24px",borderRadius:"30px",boxShadow:"0 8px 24px rgba(0,0,0,0.2)",fontSize:"15px",zIndex:2000 }}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
